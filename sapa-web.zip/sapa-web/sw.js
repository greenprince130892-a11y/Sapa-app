self.addEventListener("install",function(e){e.waitUntil(caches.open("sapa-1").then(function(c){return c.addAll(["./","index.html"])}))});
self.addEventListener("fetch",function(e){if(e.request.method!=="GET")return;e.respondWith(fetch(e.request).catch(function(){return caches.match(e.request)}))});
